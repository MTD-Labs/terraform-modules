import json
import os
import urllib.request
import urllib.error
import html

TELEGRAM_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
CHAT_ID        = os.environ.get("TELEGRAM_CHAT_ID")

def send_to_telegram(text: str):
    if not TELEGRAM_TOKEN or not CHAT_ID:
        raise RuntimeError("TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID not set in environment variables")

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"

    payload = {
        "chat_id": CHAT_ID,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"}
    )

    try:
        with urllib.request.urlopen(req) as resp:
            body = resp.read().decode("utf-8")
            print("Telegram response:", body)
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8")
        print("Telegram HTTPError:", e.code, err_body)
        raise

def build_alarm_message(subject: str, raw_msg: str) -> str:
    # Try parse CloudWatch alarm JSON
    try:
        data = json.loads(raw_msg)
    except Exception:
        safe_subject = html.escape(subject or "Alarm")
        safe_msg     = html.escape(raw_msg)
        return f"⚠️ <b>{safe_subject}</b>\\n\\n<pre>{safe_msg}</pre>"

    name    = data.get("AlarmName", "N/A")
    state   = data.get("NewStateValue", "N/A")
    reason  = data.get("NewStateReason", "")
    region  = data.get("Region", "")
    trigger = data.get("Trigger", {}) or {}

    metric    = trigger.get("MetricName", "")
    threshold = trigger.get("Threshold", "")
    dims      = trigger.get("Dimensions", {})

    resource_id = ""

    # Dimensions can be list[ {name, value}, ... ] or a single dict
    if isinstance(dims, list):
        for d in dims:
            if not isinstance(d, dict):
                continue
            dim_name  = d.get("name")
            dim_value = d.get("value", "")
            if dim_name in ("DBInstanceIdentifier", "DBClusterIdentifier", "Broker", "BrokerId"):
                resource_id = dim_value
                break
    elif isinstance(dims, dict):
        dim_name  = dims.get("name")
        dim_value = dims.get("value", "")
        if dim_name in ("DBInstanceIdentifier", "DBClusterIdentifier", "Broker", "BrokerId"):
            resource_id = dim_value

    # Emoji by state
    state_upper = str(state).upper()
    if state_upper == "ALARM":
        emoji = "❌"
    elif state_upper == "OK":
        emoji = "✅"
    else:
        emoji = "⚠️"

    # Threshold formatting
    threshold_str = ""
    if threshold != "":
        try:
            t_val = float(threshold)
            threshold_str = f"{t_val:g}"
        except Exception:
            threshold_str = str(threshold)

    # Shorten reason
    short_reason = reason.split(" (")[0] if reason else ""

    safe_state    = html.escape(state_upper)
    safe_name     = html.escape(name)
    safe_region   = html.escape(region)
    safe_resource = html.escape(resource_id) if resource_id else ""
    safe_metric   = html.escape(str(metric)) if metric else ""
    safe_thresh   = html.escape(threshold_str) if threshold_str else ""
    safe_reason   = html.escape(short_reason)

    lines = []
    lines.append(f"{emoji} <b>{safe_state}</b> CloudWatch alarm")
    lines.append(f"<b>{safe_name}</b>")

    if safe_resource:
        lines.append(f"<b>Resource:</b> {safe_resource}")

    if safe_region:
        lines.append(f"<b>Region:</b> {safe_region}")

    if safe_metric:
        if safe_thresh:
            lines.append(f"<b>Metric:</b> {safe_metric} (threshold: {safe_thresh})")
        else:
            lines.append(f"<b>Metric:</b> {safe_metric}")

    if safe_reason:
        lines.append("")
        lines.append(f"<b>Reason:</b> {safe_reason}")

    # IMPORTANT: real newlines here
    return "\\n".join(lines).replace("\\\\n", "\\n")

def lambda_handler(event, context):
    print("Incoming event:", json.dumps(event))

    records = event.get("Records", [])
    if not records:
        send_to_telegram("Test message: no Records field in event.")
        return {"statusCode": 200}

    for record in records:
        sns = record.get("Sns", {})
        raw_msg = sns.get("Message", "No SNS Message")
        subject = sns.get("Subject", "Alarm")

        text = build_alarm_message(subject, raw_msg)
        send_to_telegram(text)

    return {"statusCode": 200}
